package exercise2;

@FunctionalInterface
public interface ArithmeticOperation {
    double operate(double a, double b);
}

