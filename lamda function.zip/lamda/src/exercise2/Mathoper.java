package exercise2;

import java.util.Scanner;

public class Mathoper {
    public static void main(String[] args) {
        // Lambda expressions for arithmetic operations
        ArithmeticOperation addition = (a, b) -> a + b;
        ArithmeticOperation subtraction = (a, b) -> a - b;
        ArithmeticOperation multiplication = (a, b) -> a * b;
        ArithmeticOperation division = (a, b) -> {
            if (b == 0) {
                System.out.println("Error: Division by zero is not allowed.");
                return 0;
            }
            return a / b;
        };

        // Read input from the keyboard
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the first number: ");
        double num1 = scanner.nextDouble();

        System.out.println("Enter the second number: ");
        double num2 = scanner.nextDouble();

        System.out.println("Choose an operation (+, -, *, /): ");
        char operation = scanner.next().charAt(0);

        // Apply the chosen operation and print the result
        double result;
        switch (operation) {
            case '+':
                result = performOperation(num1, num2, addition);
                System.out.println("Result: " + result);
                break;
            case '-':
                result = performOperation(num1, num2, subtraction);
                System.out.println("Result: " + result);
                break;
            case '*':
                result = performOperation(num1, num2, multiplication);
                System.out.println("Result: " + result);
                break;
            case '/':
                result = performOperation(num1, num2, division);
                System.out.println("Result: " + result);
                break;
            default:
                System.out.println("Invalid operation selected.");
        }
    }

    public static double performOperation(double a, double b, ArithmeticOperation operation) {
        return operation.operate(a, b);
    }
}
