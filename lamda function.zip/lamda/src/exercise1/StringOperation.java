package exercise1;

@FunctionalInterface
public interface StringOperation {
    String operate(String s);
}
