package exercise1;

import java.util.Scanner;

public class Exercise1 {
    public static void main(String[] args) {
        StringOperation reverseOperation = (s) -> new StringBuilder(s).reverse().toString();

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();

        // Apply the operation and print the result
        System.out.println("Reversed string: " + applyOperation(input, reverseOperation));
    }

    public static String applyOperation(String s, StringOperation operation) {
        return operation.operate(s);
    }
}
