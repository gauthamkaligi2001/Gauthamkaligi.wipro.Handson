package exercise3;

@FunctionalInterface
interface PassUser {
    boolean authenticate(String username, String password);
}