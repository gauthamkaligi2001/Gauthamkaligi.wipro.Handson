package exercise3;

@FunctionalInterface
interface ArthmOper {
    double operate(double x, double y);
}
