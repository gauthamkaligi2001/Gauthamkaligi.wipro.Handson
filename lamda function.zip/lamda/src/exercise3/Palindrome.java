package exercise3;

import java.util.Scanner;

public class Palindrome {
    public static void main(String[] args) {
    	 StringTest isPalindrome = (s) -> s.equalsIgnoreCase(new StringBuilder(s).reverse().toString());
    	 StringTest containsCharacter = (s) -> s.contains("a");
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();
        System.out.println("Is palindrome: " + isPalindrome.test(input));
        System.out.println("Contains character 'a': " + containsCharacter.test(input));
    }
}
