package exercise3;

import java.util.Scanner;

public class Passworduser {
    public static void main(String[] args) {
              PassUser authenticator = (username, password) -> "admin".equals(username) && "password123".equals(password);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter username: ");
        String username = scanner.nextLine();
        System.out.println("Enter password: ");
        String password = scanner.nextLine();     
        boolean isAuthenticated = authenticator.authenticate(username, password);
        System.out.println("Authentication " + (isAuthenticated ? "successful" : "failed"));
    }

   
}

