package exercise3;

@FunctionalInterface
interface StringTest {
    boolean test(String s);
}
