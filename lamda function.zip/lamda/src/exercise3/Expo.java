package exercise3;

import java.util.Scanner;

public class Expo {
    public static void main(String[] args) {
        
   	ArthmOper exponentiation = (x, y) -> Math.pow(x, y);       
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter base number: ");
        double base = scanner.nextDouble();
        System.out.println("Enter exponent number: ");
        double exponent = scanner.nextDouble();    
        System.out.println("Result: " + exponentiation.operate(base, exponent));
    }

   
}
