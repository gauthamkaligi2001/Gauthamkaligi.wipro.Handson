package exercise3;

import java.util.Scanner;

public class Space {
    public static void main(String[] args) {
        Spaceinter formatWithSpaces = (s) -> String.join(" ", s.split(""));
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();
        System.out.println("Formatted string: " + formatWithSpaces.transform(input));
    }

    
}
