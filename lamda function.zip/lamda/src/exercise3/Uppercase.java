package exercise3;

import java.util.Scanner;

public class Uppercase {
    public static void main(String[] args) {
    	 StringTransform toUpperCase = (s) -> s.toUpperCase();
        StringTransform reverseString = (s) -> new StringBuilder(s).reverse().toString();
        
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scanner.nextLine();   
        System.out.println("Uppercase: " + toUpperCase.transform(input));
        System.out.println("Reversed: " + reverseString.transform(input));
    }
}
