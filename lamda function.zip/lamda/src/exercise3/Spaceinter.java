package exercise3;

@FunctionalInterface
interface Spaceinter {
    String transform(String s);
}