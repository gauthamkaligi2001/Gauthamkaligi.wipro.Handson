package exercise3;

@FunctionalInterface
interface StringTransform {
    String transform(String s);
}
